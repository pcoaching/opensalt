<?php

namespace App\Command\User;

class ActivateUserCommand extends UserCommand
{
}
