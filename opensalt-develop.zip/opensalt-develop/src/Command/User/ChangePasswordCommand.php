<?php

namespace App\Command\User;

class ChangePasswordCommand extends AddUserCommand
{
}
