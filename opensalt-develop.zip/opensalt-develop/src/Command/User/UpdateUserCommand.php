<?php

namespace App\Command\User;

class UpdateUserCommand extends UserCommand
{
}
