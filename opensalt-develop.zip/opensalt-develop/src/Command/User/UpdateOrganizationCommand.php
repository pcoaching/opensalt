<?php

namespace App\Command\User;

class UpdateOrganizationCommand extends OrganizationCommand
{
}
