<?php

namespace App\Command\User;

class AddOrganizationCommand extends OrganizationCommand
{
}
