<?php

namespace App\Command\User;

class DeleteOrganizationCommand extends OrganizationCommand
{
}
