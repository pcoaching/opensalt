<?php

namespace App\Command\User;

class SuspendUserCommand extends UserCommand
{
}
