<?php

namespace App\Command\User;

class DeleteUserCommand extends UserCommand
{
}
