<?php

namespace App\Command\Framework;

class UnlockDocumentCommand extends LockDocumentCommand
{
}
