<?php

namespace App\Command\Framework;

class UnlockItemCommand extends LockItemCommand
{
}
