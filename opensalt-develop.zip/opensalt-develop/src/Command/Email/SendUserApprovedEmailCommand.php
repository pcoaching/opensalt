<?php

namespace App\Command\Email;

class SendUserApprovedEmailCommand extends AbstractSendEmailCommand
{
}
