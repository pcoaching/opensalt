<?php

namespace App\Command\Email;

class SendSignupReceivedEmailCommand extends AbstractSendEmailCommand
{
}
