<?php

namespace App\Exception;

class AlreadyLockedException extends \RuntimeException
{
}
