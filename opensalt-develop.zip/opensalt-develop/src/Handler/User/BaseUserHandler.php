<?php

namespace App\Handler\User;

use App\Handler\BaseDoctrineHandler;

/**
 * Class BaseUserHandler
 */
abstract class BaseUserHandler extends BaseDoctrineHandler
{
}
