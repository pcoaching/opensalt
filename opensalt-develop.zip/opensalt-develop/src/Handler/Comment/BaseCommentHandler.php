<?php

namespace App\Handler\Comment;

use App\Handler\BaseDoctrineHandler;

/**
 * Class BaseCommentHandler
 */
abstract class BaseCommentHandler extends BaseDoctrineHandler
{
}
