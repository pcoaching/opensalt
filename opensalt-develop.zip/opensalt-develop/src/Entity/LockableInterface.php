<?php

namespace App\Entity;

interface LockableInterface
{
    public function getId(): ?int;
}
