<?php

namespace App\Entity;

class NotificationOnlyChangeEntry extends ChangeEntry
{
}
