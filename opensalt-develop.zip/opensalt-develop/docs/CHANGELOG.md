Changelog
=========

* 1.1.x
 * added protection to the `app_dev.php` front controller
